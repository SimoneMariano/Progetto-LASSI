$(document).ready(function(){

    $('#categories').selectpicker();
    $('#authors').selectpicker();



});
