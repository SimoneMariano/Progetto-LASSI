let selectpicker_render = {
    setup: function() {
        $('.selectpicker').selectpicker();
    }

}  

$(selectpicker_render.setup)
;
