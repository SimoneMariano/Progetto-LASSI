$(document).ready(function(){    
    $("#profile-image").on("click", function() {
        $("#user_image").click();
    });
});
