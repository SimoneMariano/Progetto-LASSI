$("#b1").click( function(){


    alert("funziono")
}); 
