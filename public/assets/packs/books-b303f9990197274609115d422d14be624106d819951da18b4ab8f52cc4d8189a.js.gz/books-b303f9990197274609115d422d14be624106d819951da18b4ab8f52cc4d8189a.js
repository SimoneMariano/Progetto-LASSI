/*let Add_select = */$("addCategory").click(function(){
    console.log("ok")
    alert("ok")
    $("#categories").clone().appendTo("#select-div");
});

//$(Add_select.setup);
