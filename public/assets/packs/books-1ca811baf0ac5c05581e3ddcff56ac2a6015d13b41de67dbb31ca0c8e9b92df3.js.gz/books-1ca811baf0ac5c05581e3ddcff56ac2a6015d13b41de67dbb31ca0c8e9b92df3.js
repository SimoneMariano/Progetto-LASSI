$("#add_category").click(function(){
    $("#categories").clone().appendTo("#select-div");
});
