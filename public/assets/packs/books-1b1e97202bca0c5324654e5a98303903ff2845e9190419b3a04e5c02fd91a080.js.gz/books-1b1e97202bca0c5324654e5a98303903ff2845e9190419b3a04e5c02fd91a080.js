/*let Add_select = */$(".btn").click(function(){
    console.log("ok")
    alert("ok")
    $("#categories").clone().appendTo("#select-div");
});

//$(Add_select.setup);
