$("#add_category").click(function(){
    alert("ok")
    $("#categories").clone().appendTo("#select-div");
});
