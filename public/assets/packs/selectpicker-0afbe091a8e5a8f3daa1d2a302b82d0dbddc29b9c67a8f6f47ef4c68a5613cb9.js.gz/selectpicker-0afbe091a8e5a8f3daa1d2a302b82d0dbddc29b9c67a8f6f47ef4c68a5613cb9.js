$(document).ready(function(){

    $('#categories').selectpicker();
    $('#authors').selectpicker();

    $(".selectpicker").selectpicker({
        "title": "Select Options"        
    }).selectpicker("render");

});
