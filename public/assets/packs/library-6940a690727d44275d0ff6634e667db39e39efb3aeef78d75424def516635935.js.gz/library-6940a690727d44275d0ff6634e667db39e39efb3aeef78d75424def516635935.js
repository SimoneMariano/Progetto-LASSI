$("#b1").click( function(){

    alert("Caro valerio")
});
