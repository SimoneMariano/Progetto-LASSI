let Add_select = $("#add_category").click(function(){
    alert("ok")
    $("#categories").clone().appendTo("#select-div");
});

alert("2")

$(Add_select.setup);
