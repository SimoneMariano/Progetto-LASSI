
import "@rails/ujs"
require("@rails/ujs").start();
