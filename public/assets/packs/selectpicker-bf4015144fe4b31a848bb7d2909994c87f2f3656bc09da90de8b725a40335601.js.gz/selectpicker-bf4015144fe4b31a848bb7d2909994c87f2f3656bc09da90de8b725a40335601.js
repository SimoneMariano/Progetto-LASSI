let selectpicker_render = {
    render: function(){
        $('.selectpicker').selectpicker();
    
    },
    setup: function() {
        this.render;
    }

}  

$(selectpicker_render.setup)

;
