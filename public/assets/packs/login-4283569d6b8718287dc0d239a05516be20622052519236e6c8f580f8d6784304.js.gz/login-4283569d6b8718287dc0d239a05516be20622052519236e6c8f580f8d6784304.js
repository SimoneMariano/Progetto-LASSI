$("#login-form").on("click", function() {
    let form = document.getElementById("login-form");
    form.submit(); 
});
