
$(document).ready(function(){
    $("#ul-categories").css("display","none");

    //mostra le categorie al click
    $("input[type=radio]").on("change", function(){
        var valore = $(this).val()
        if(valore != "Categories"){
            $("#ul-categories").css("display","none");
        }else{
            $("#ul-categories").css("display","block");
        }
    }); 

});
