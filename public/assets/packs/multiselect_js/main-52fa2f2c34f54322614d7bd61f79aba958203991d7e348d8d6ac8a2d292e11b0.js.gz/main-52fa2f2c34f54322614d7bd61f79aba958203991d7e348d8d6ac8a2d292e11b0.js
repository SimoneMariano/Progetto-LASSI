$(function(){
    $(".chosen-select").chosen(); 
});
