$(document).ready(function(){
    $("#ul-categories").css("display","none");

    

})
;
