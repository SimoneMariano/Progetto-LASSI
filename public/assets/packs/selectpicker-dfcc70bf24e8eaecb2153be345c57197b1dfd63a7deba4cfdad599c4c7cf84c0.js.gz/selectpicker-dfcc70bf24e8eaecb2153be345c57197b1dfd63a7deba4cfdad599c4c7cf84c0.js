$(document).ready(function(){

    $('#categories').selectpicker();


});
