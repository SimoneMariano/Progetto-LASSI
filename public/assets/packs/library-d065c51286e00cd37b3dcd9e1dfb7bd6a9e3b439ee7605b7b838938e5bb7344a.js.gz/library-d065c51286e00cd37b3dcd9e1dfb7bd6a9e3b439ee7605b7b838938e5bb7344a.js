$("#b1").click( function(){

    alert("funzioooojno")
});
