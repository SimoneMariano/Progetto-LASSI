$("#b1").click( function(){

    alert("Caro mauro")
});
